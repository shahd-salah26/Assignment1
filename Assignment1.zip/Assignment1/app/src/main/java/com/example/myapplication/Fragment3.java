package com.example.myapplication;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.CheckBox;

import androidx.fragment.app.Fragment;

public class Fragment3 extends Fragment {

    public interface OnAgreementChangedListener {
        void onAgreementChanged(boolean agreed);
    }

    private OnAgreementChangedListener listener;

    private static final String ARG_NAME = "name";

    public Fragment3() {
    }

    public static Fragment3 newInstance(String name) {
        Fragment3 fragment = new Fragment3();

        Bundle args = new Bundle();
        args.putString(ARG_NAME, name);
        fragment.setArguments(args);

        return fragment;
    }

    @Override
    public void onAttach(android.content.Context context) {
        super.onAttach(context);

        if (context instanceof OnAgreementChangedListener) {
            listener = (OnAgreementChangedListener) context;
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_3, container, false);

        TextView textViewWelcome = view.findViewById(R.id.textViewWelcome);
        CheckBox checkBoxAgree = view.findViewById(R.id.checkBoxAgree);

        String name = getArguments() != null
                ? getArguments().getString(ARG_NAME)
                : "";

        textViewWelcome.setText("Welcome " + name);

        checkBoxAgree.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (listener != null) {
                listener.onAgreementChanged(isChecked);
            }
        });

        return view;
    }

    @Override
    public void onDetach() {
        super.onDetach();
        listener = null;
    }
}