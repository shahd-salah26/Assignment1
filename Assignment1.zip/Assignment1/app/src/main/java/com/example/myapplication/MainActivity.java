package com.example.myapplication;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import android.os.Bundle;
import android.widget.Toast;
import com.example.myapplication.databinding.ActivityMainBinding;
public class MainActivity extends AppCompatActivity
        implements Fragment2.OnFragmentInteractionListener,
        Fragment3.OnAgreementChangedListener {
    private ActivityMainBinding binding;
    private int currentFragment = 1;
    private String name;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        if (savedInstanceState == null) {
            Fragment1 fragment1 = Fragment1.newInstance(null, null);
            getSupportFragmentManager()
                    .beginTransaction()
                    .add(R.id.fragment_container, fragment1)
                    .commit();
        }

        binding.buttonContinue.setOnClickListener(view -> {

            if (currentFragment == 1) {

                Fragment2 fragment2 = Fragment2.newInstance(null, null);

                getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.fragment_container, fragment2)
                        .addToBackStack(null)
                        .commit();

                currentFragment = 2;

            } else if (currentFragment == 2) {

                Fragment fragment = getSupportFragmentManager()
                        .findFragmentById(R.id.fragment_container);

                if (fragment instanceof Fragment2) {
                    ((Fragment2) fragment).submitName();
                }

            } else if (currentFragment == 3) {

                Toast.makeText(this, "Finished!", Toast.LENGTH_SHORT).show();
                finish();
            }
        });
    }

    @Override
    public void onNameEntered(String name) {

        this.name = name;

        Fragment3 fragment3 = Fragment3.newInstance(name);

        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment_container, fragment3)
                .addToBackStack(null)
                .commit();

        currentFragment = 3;

        binding.buttonContinue.setEnabled(false);
        binding.buttonContinue.setText("CONTINUE");
    }

    @Override
    public void onAgreementChanged(boolean agreed) {

        binding.buttonContinue.setEnabled(agreed);

        if (agreed) {
            binding.buttonContinue.setText("FINISH");
        } else {
            binding.buttonContinue.setText("CONTINUE");
        }
    }
}